package FusionInventory::Agent::Task::Inventory::OS::Generic;

use strict;
use warnings;

sub doInventory {}

1;
